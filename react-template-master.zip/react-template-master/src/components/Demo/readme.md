```js
<Demo name='React' />
```
